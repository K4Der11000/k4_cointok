from flask import Flask, render_template, request, jsonify, redirect, url_for, session
import threading, time, json, os

app = Flask(__name__)
app.secret_key = "supersecretkey"

PASSWORD = "kader11000"

data_file = "progress.json"
log = []
bot_running = False
points = 0
views = 0

def save_progress():
    with open(data_file, "w") as f:
        json.dump({"points": points, "views": views}, f)

def load_progress():
    global points, views
    if os.path.exists(data_file):
        with open(data_file) as f:
            progress = json.load(f)
            points = progress.get("points", 0)
            views = progress.get("views", 0)

def bot_loop(site):
    global bot_running, points, views
    log.append(f"Starting bot on {site}...")
    while bot_running:
        time.sleep(2)
        points += 1
        views += 1
        log.append(f"[{site}] Earned 1 point | Total Points: {points}, Views: {views}")
        save_progress()
    log.append("Bot stopped.")

@app.route("/", methods=["GET"])
def home():
    if not session.get("logged_in"):
        return redirect(url_for("login"))
    return render_template("index.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if request.form.get("password") == PASSWORD:
            session["logged_in"] = True
            return redirect(url_for("home"))
        else:
            return render_template("login.html", error="Invalid password.")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.pop("logged_in", None)
    return redirect(url_for("login"))

@app.route("/start", methods=["POST"])
def start_bot():
    global bot_running
    if not bot_running:
        bot_running = True
        site = request.form["site"]
        thread = threading.Thread(target=bot_loop, args=(site,), daemon=True)
        thread.start()
    return "", 204

@app.route("/stop", methods=["POST"])
def stop_bot():
    global bot_running
    bot_running = False
    return "", 204

@app.route("/status")
def status():
    return jsonify({
        "points": points,
        "views": views,
        "log": log[-50:]
    })

if __name__ == "__main__":
    load_progress()
    app.run(debug=True)
